//
//  newViewController.swift
//  NewTablels
//
//  Created by:
//  Salazar Olivares Ricardo
//  Yonatan Martin Galicia Serrano
//  on 08/10/24.
//

import UIKit

class newViewController: UIViewController {
    
    static let identifier = "second-screen"
    
    @IBOutlet weak var detailIMage: UIImageView!
    @IBOutlet weak var detailLabel: UILabel!
    var detailLabelText: String = ""
    var detailImageName: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        detailLabel.text = detailLabelText
        detailIMage.image = UIImage(named: detailImageName)
        detailIMage.layer.cornerRadius = 100
        detailIMage.layer.borderWidth = 10
        detailIMage.layer.borderColor = UIColor.black.cgColor
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
