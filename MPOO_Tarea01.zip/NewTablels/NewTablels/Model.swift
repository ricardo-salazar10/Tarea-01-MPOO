//
//  Model.swift
//  NewTablels
//
//  Created by:
//  Salazar Olivares Ricardo
//  Yonatan Martin Galicia Serrano
//  on 08/10/24.
//

import Foundation

struct User {
    var username: String
    var userImage: String
}
