//
//  ViewController.swift
//  NewTablels
//
//  //  Created by:
//  Salazar Olivares Ricardo
//  Yonatan Martin Galicia Serrano
//  on 08/10/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var users: [User] = [User(username: "Usuario 1", userImage: "user1"), User(username: "Usuario 2", userImage: "user2"), User(username: "Usuario 3", userImage: "user3")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(MyTableViewCell.nib(), forCellReuseIdentifier: MyTableViewCell.identifier)
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: newViewController.identifier) as! newViewController
        
        // vc.navigationItem.title = users[indexPath.row].username
        navigationController?.pushViewController(vc, animated: true)
        vc.detailLabelText = users[indexPath.row].username
        vc.detailImageName = users[indexPath.row].userImage
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MyTableViewCell.identifier, for: indexPath) as! MyTableViewCell
        
        cell.customImageView.image = UIImage(named: users[indexPath.row].userImage)
        cell.customLabel.text = users[indexPath.row].username
        
        return cell
    }

}

